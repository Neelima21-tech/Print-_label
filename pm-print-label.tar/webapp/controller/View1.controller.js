sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/filterbar/FilterBar",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/model/Filter",
    "sap/ui/model/type/String",
    "sap/ui/model/FilterOperator",
    "sap/m/SearchField",
    "sap/ui/comp/valuehelpdialog/ValueHelpDialog",
    "sap/ui/comp/filterbar/FilterGroupItem",
    "sap/m/ColumnListItem",
    "sap/m/Label",
    "sap/ui/table/Column",
    "sap/m/Column",
    "sap/m/Text",
    "sap/ui/core/Fragment",
    "sap/ui/core/BusyIndicator",
    "sap/m/MessageBox",
  ],
  function (
    Controller,
    FilterBar,
    ODataModel,
    Filter,
    TypeString,
    FilterOperator,
    SearchField,
    ValueHelpDialog,
    FilterGroupItem,
    ColumnListItem,
    Label,
    UIColumn,
    MColumn,
    Text,
    Fragment,
    BusyIndicator,
    MessageBox
  ) {
    "use strict";
    return Controller.extend("com.wl.pm.zmatpmlabel.controller.View1", {
      onInit: function () {
        // Create and set the OData model
        this.oModel = this.getOwnerComponent().getModel("ZPM_SB_PRINT_LABEL");
        this.oProductsModel =
          this.getOwnerComponent().getModel("ZPM_SB_PRINT_LABEL");
        // this.oPlantModel = this.getOwnerComponent().getModel("ZMM_BND_TVARVC");

        var oLocalModel = new sap.ui.model.json.JSONModel({
          selectedPlant: "",
          selectedPrinter: "",
          counterStart: "",
          selectedMaterial: [],
          selectedMatCondition: [],
          selectedSloc: [],
          selectedSlocCondition: [],
        });
        this.getView().setModel(oLocalModel);

        //multi material
        var oMultiInputWithSuggestions = this.byId(
          "multiInputWithSuggestionsMat"
        );
        oMultiInputWithSuggestions.addValidator(this._onMultiInputValidate);
        //
        this._oMultiInputWithSuggestions = oMultiInputWithSuggestions;

        //multi sloc
        var oMultiInputWithSuggestionsSloc = this.byId(
          "multiInputWithSuggestionsSloc"
        );
        oMultiInputWithSuggestionsSloc.addValidator(
          this._onMultiInputValidateSloc
        );
        //
        this._oMultiInputWithSuggestionsSloc = oMultiInputWithSuggestionsSloc;

        // condition to disable material till plant provided
        this.oPlantInput = this.byId("inputPlant");
        this.oMaterialInput = this.byId("multiInputWithSuggestionsMat");
        this.oStorageLocation = this.byId("multiInputWithSuggestionsSloc");
        this.oNoOfCountInput = this.byId("inputNoOfCount");
        this.oPrinterInput = this.byId("inputPrinter");
        this.oExecuteButton = this.byId("executeButton");

        // Set default value for No of Count input
        this.oNoOfCountInput.setValue("1");
        this._setButtonEnabled(false);
        this._setMaterialInputEnabled(false);
        this._setSlocInputEnabled(false); //--disable the comment

        // add event list
        this.oPlantInput.attachChange(this._onPlantInputChange, this);
        this.oMaterialInput.attachChange(this._onMatInputChange, this);
        this.oStorageLocation.attachChange(this._onSlocChange, this);
        this.oPrinterInput.attachChange(this._onPrinterChange, this);
        this.oNoOfCountInput.attachChange(this._onCountChange, this);
      },
      _setMaterialInputEnabled: function (bEnabled) {
        this.oMaterialInput.setEnabled(bEnabled);
        this.oMaterialInput.setShowValueHelp(bEnabled);
      },

      _setSlocInputEnabled: function (bEnabled) {
        this.oStorageLocation.setEnabled(bEnabled);
        this.oStorageLocation.setShowValueHelp(bEnabled);
      },
      _setButtonEnabled: function (bEnabled) {
        this.oExecuteButton.setEnabled(bEnabled);
      },
      _onPlantInputChange: async function () {
        //
        var that = this;
        var plantFlag = false;
        var sPlantValue = this.byId("inputPlant").getValue().toUpperCase();
        var oModel = this.getOwnerComponent().getModel("ZPM_SB_PRINT_LABEL"); 

        var aFilters = [new Filter("Plant", FilterOperator.EQ, sPlantValue)];

        try {
          var oData = await this._checkPlantAvailability(oModel, aFilters);
          if (oData.results && oData.results.length > 0) {
            plantFlag = true;
          } else {
            
            sap.m.MessageToast.show("Plant is not available.");
            plantFlag = false;
          }
        } catch (oError) {
          MessageToast.show(
            "Error occurred while checking plant availability."
          );
        }

        this.byId("multiInputWithSuggestionsMat").setTokens([]);
        this.byId("multiInputWithSuggestionsMat").setValue("");
        this.byId("inputBin").setValue("");
        this.byId("multiInputWithSuggestionsSloc").setTokens([]);
        this.byId("multiInputWithSuggestionsSloc").setValue("");
        this.byId("inputPrinter").setValue("");

        if (!plantFlag) {
          this._setButtonEnabled(false);
          this._setMaterialInputEnabled(false);
          this._setSlocInputEnabled(false);
        } else {
          this._setMaterialInputEnabled(!!sPlantValue);
          this._setSlocInputEnabled(false);
          this._setButtonEnabled(false);
          this._updateFieldWithDefaultPrinter(sPlantValue);
        }
      },
      _onMatInputChange: function () {
        var MatValue =
          this.oMaterialInput.getValue() ||
          this.oMaterialInput.getTokens().length > 0;
        this._setSlocInputEnabled(!!MatValue); // Enable material input if plant value is not empty

        this.mandateCheck();
      },
      _onSlocChange: function () {
        var SlocVal =
          this.oStorageLocation.getValue() || this.oStorageLocation.getTokens();

        this.mandateCheck();
      },
      _onPrinterChange: function () {
        this.mandateCheck();
      },
      _onCountChange: function () {
        this.mandateCheck();
      },

      //:--plant help

      changei18n:function(sText)
            {
                var oResourceBundle=this.getOwnerComponent().getModel("i18n");
                var cText=oResourceBundle.getResourceBundle().getText(sText);
                return cText;
            },
      onValueHelpRequest: function () {
        var that = this;
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog = new ValueHelpDialog({
            title: "Select Plant",
            supportMultiselect: false,
            ok: this._onValueHelpOk.bind(this),
            cancel: this._onValueHelpCancel.bind(this),    
            afterClose: this._onValueHelpAfterClose.bind(this),
          });
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label:  this.changei18n("Print.maincontroller_plant"), template: "Plant" }, //Low
              { label: this.changei18n("print.maincontroller_descr"), template: "PlantName" }, //High
              { label: this.changei18n("print.maincontroller_langua"), template:"Language"}
            ],
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            oTable.setModel(that.oProductsModel); 
            oTable.bindAggregation("rows", {
              path: "/I_Plant", 

              events: {
                dataReceived: function () {
                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOk: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").Plant;

          this.getView().byId("inputPlant").setValue(sSelectedValue);
          this.getView()
            .getModel()
            .setProperty("/selectedPlant", sSelectedValue);
        }
        this._oValueHelpDialog.close();
        this._onPlantInputChange();
        //
      },

      _onValueHelpCancel: function () {
        this._oValueHelpDialog.close();
        //
      },

      _onValueHelpAfterClose: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End plant help

      //:-- mat help
      onValueHelpWithSuggestionsRequested: function () {
        var sPlant = this.byId("inputPlant").getValue().toUpperCase();
        var sSbin = this.byId("inputBin").getValue();

        this._oBasicSearchFieldWithSuggestions = new SearchField();

        this.pDialogWithSuggestions = this.loadFragment({
          name: "com.wl.pm.zmatpmlabel.fragment.ValueHelpDialogFilterbarWithSuggestions",
        }).then(
          function (oDialogSuggestions) {
            var oFilterBar = oDialogSuggestions.getFilterBar(),
              oColumnProductCode,
              oColumnProductName,
              oColumnProductDesc;
            this._oVHDWithSuggestions = oDialogSuggestions;

            this.getView().addDependent(oDialogSuggestions);

            // Set key fields for filtering in the Define Conditions Tab
            oDialogSuggestions.setRangeKeyFields([
              {
                label: this.changei18n("Print.maincontroller_plant"),
                key: "Plant",
                type: "string",
                typeInstance: new TypeString(
                  {},
                  {
                    maxLength: 9,
                  }
                ),
              },
            ]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchFieldWithSuggestions);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchFieldWithSuggestions.attachSearch(function () {
              oFilterBar.search();
            });

            oDialogSuggestions.getTableAsync().then(
              function (oTable) {
                oTable.setModel(this.oProductsModel);

                // For Desktop and tabled the default table is sap.ui.table.Table
                if (oTable.bindRows) {
                  var aFilters = [
                    new Filter("Plant", FilterOperator.EQ, sPlant),
                  ];
                  if (sSbin) {
                    aFilters.push(
                      new Filter("Storagebin", FilterOperator.EQ, sSbin)
                    );
                  }
                  // Bind rows to the ODataModel and add columns
                  oTable.bindAggregation("rows", {
                    path: "/zpm_cds_matrial_F4",
                    filters: aFilters, //[new Filter("Plant", FilterOperator.EQ, sPlant)],
                    events: {
                      dataReceived: function () {
                        oDialogSuggestions.update();
                      },
                    },
                  });
                  oColumnProductCode = new UIColumn({
                    label: new Label({ text: this.changei18n("Print.maincontroller_plant") }),
                    template: new Text({ wrapping: false, text: "{Plant}" }),
                  });
                  oColumnProductCode.data({
                    fieldName: "Plant",
                  });
                  oTable.addColumn(oColumnProductCode);

                  oColumnProductName = new UIColumn({
                    label: new Label({ text: this.changei18n("Print.maincontroller_product") }),
                    template: new Text({ wrapping: false, text: "{Product}" }),
                  });
                  oColumnProductName.data({
                    fieldName: "Product",
                  });
                  oTable.addColumn(oColumnProductName);

                  oColumnProductDesc = new UIColumn({
                    label: new Label({ text: "{i18n>print.maincontroller_descr}" }),
                    template: new Text({
                      wrapping: false,
                      text: "{MaterialDescription}",
                    }),
                  });
                  oColumnProductDesc.data({
                    fieldName: "MaterialDescription",
                  });
                  oTable.addColumn(oColumnProductDesc);

                  oColumnProductDesc = new UIColumn({
                    label: new Label({ text: this.changei18n("print.maincontroller_storage") }),
                    template: new Text({
                      wrapping: false,
                      text: "{StorageLoc}",
                    }),
                  });
                  oColumnProductDesc.data({
                    fieldName: "StorageLoc",
                  });
                  oTable.addColumn(oColumnProductDesc);
                }

                // For Mobile the default table is sap.m.Table
                if (oTable.bindItems) {
                  var aFilters = [
                    new Filter("Plant", FilterOperator.EQ, sPlant),
                  ];
                  if (sSbin) {
                    aFilters.push(
                      new Filter("Storagebin", FilterOperator.EQ, sSbin)
                    );
                  }
                  // Bind items to the ODataModel and add columns
                  oTable.bindAggregation("items", {
                    path: "/zpm_cds_matrial_F4",
                    filters: aFilters, //[new Filter("Plant", FilterOperator.EQ, sPlant)],
                    template: new ColumnListItem({
                      cells: [
                        new Label({ text: this.changei18n("Print.maincontroller_plant") }),
                        new Label({ text: this.changei18n("Print.maincontroller_product") }),
                        new Label({ text: this.changei18n("printlabel.main.material") }),
                        new Label({ text: this.changei18n("printlabel.main.storage") }),
                      ],
                    }),
                    events: {
                      dataReceived: function () {
                        oDialogSuggestions.update();
                      },
                    },
                  });
                  oTable.addColumn(
                    new MColumn({ header: new Label({ text: this.changei18n("Print.maincontroller_plant") }) })
                  );
                  oTable.addColumn(
                    new MColumn({ header: new Label({ text: this.changei18n("Print.maincontroller_product") }) })
                  );
                  oTable.addColumn(
                    new MColumn({
                      header: new Label({ text: this.changei18n("printlabel.main.material") }),
                    })
                  );
                  oTable.addColumn(
                    new MColumn({
                      header: new Label({ text: this.changei18n("printlabel.main.storage") }),
                    })
                  );
                }
                oDialogSuggestions.update();
              }.bind(this)
            );

            oDialogSuggestions.setTokens(
              this._oMultiInputWithSuggestions.getTokens()
            );
            oDialogSuggestions.open();
          }.bind(this)
        );
      },

      onValueHelpWithSuggestionsOkPress: function (oEvent) {
        var aMaterials = [];
        var aTokens = oEvent.getParameter("tokens");
        this._oMultiInputWithSuggestions.setTokens(aTokens);
        aTokens.forEach(function (oToken) {
          var sMaterialKey = oToken.getKey();

          aMaterials.push(sMaterialKey);
        }, this);
        // --filter
        var aFilter = [];
        aTokens.forEach((token) => {
          var oFilter = this._formFilter(token, "Product");
          if (oFilter) aFilter.push(oFilter);
        });

        if (aMaterials.length > 0) {
          var oMaterialInput = this.getView().byId(
            "multiInputWithSuggestionsMat"
          );
          var oModel = this.getView().getModel();

          // Set the collected materials to the model
          oModel.setProperty("/selectedMatCondition", aFilter);
          oModel.setProperty("/selectedMaterial", aMaterials);
          this._setMaterialInputEnabled(true);
          // Set the tokens to the material input field
          oMaterialInput.removeAllTokens();
          aMaterials.forEach(function (sMaterial) {
            oMaterialInput.addToken(
              new sap.m.Token({ key: sMaterial, text: sMaterial })
            );
          });
          this.getView().byId("multiInputWithSuggestionsMat").setValue("");
          // this.oMaterialInput.setEnabled(false);
        } else {
        }
        //

        //
        this._oVHDWithSuggestions.close();
        this._onMatInputChange();
        this.onValueChange(); // FUT- 14-08 18:47
      },

      onValueHelpWithSuggestionsCancelPress: function () {
        this._oVHDWithSuggestions.close();
        this._onMatInputChange();
        this.onValueChange(); // FUT- 14-08 18:47
      },

      onFilterBarWithSuggestionsSearch: function (oEvent) {
        var sSearchQuery = this._oBasicSearchFieldWithSuggestions.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet"),
          aFilters =
            aSelectionSet &&
            aSelectionSet.reduce(function (aResult, oControl) {
              if (oControl.getValue()) {
                aResult.push(
                  new Filter({
                    path: oControl.getName(),
                    operator: FilterOperator.Contains,
                    value1: oControl.getValue(),
                  })
                );
              }

              return aResult;
            }, []);

        aFilters.push(
          new Filter({
            filters: [
              new Filter({
                path: "Plant",
                operator: FilterOperator.Contains,
                value1: sSearchQuery,
              }),
              new Filter({
                path: "Product",
                operator: FilterOperator.Contains,
                value1: sSearchQuery,
              }),
            ],
            and: false,
          })
        );

        this._filterTableWithSuggestions(
          new Filter({
            filters: aFilters,
            and: true,
          })
        );
      },

      _filterTableWithSuggestions: function (oFilter) {
        var oVHD = this._oVHDWithSuggestions;
        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }
          oVHD.update();
        });
      },

      onValueHelpWithSuggestionsAfterClose: function () {
        this._oVHDWithSuggestions.destroy();
        this._onMatInputChange();
        this.onValueChange(); // FUT- 14-08 18:47
      },

      ///Value help for Storage location   StorageLocation
      onValueHelpWithSuggestionsRequestedSloc: function () {
        var that = this;
        var sPlant = this.byId("inputPlant").getValue().toUpperCase();
        var sSbin = this.byId("inputBin").getValue();
        var sMaterial = this.byId("multiInputWithSuggestionsMat").getValue();
        var sMaterialfilter = this.getView()
          .getModel()
          .getProperty("/selectedMatCondition");

        var oPlantFilter = new Filter("Plant", FilterOperator.EQ, sPlant);
        var oMaterialFilter;
        if (sMaterial) {
          oMaterialFilter = new Filter("Product", FilterOperator.EQ, sMaterial);
        } else {
          oMaterialFilter = new Filter({
            filters: sMaterialfilter,
            and: false,
          });
        }
        var aFilters = [oPlantFilter, oMaterialFilter];

        if (sSbin) {
          var oSloacFilter = new Filter(
            "WarehouseStorageBin",
            FilterOperator.EQ,
            sSbin
          );
          aFilters.push(oSloacFilter);
        }
        var aAllFilters = new Filter({
          filters: aFilters,
          and: true,
        });

        this._oBasicSearchFieldWithSuggestions = new SearchField();

        this.pDialogWithSuggestions = this.loadFragment({
          name: "com.wl.pm.zmatpmlabel.fragment.ValueHelpDialogFilterbarWithSuggestionsSloc",
        }).then(
          function (oDialogSuggestions) {
            var oFilterBar = oDialogSuggestions.getFilterBar(),
              oColumnStorageLocation,
              oColumnPlant;
            this._oVHDWithSuggestions = oDialogSuggestions;

            this.getView().addDependent(oDialogSuggestions);

            // Set key fields for filtering in the Define Conditions Tab
            oDialogSuggestions.setRangeKeyFields([
              {
                label: this.changei18n("print.maincontroller_storage"),
                key: "StorageLocation",
                type: "string",
                typeInstance: new TypeString(
                  {},
                  {
                    maxLength: 7,
                  }
                ),
              },
            ]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchFieldWithSuggestions);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchFieldWithSuggestions.attachSearch(function () {
              oFilterBar.search();
            });

            oDialogSuggestions.getTableAsync().then(
              function (oTable) {
                oTable.setModel(this.oProductsModel);

                // For Desktop and tabled the default table is sap.ui.table.Table
                if (oTable.bindRows) {
                  // Bind rows to the ODataModel and add columns
                  oTable.bindAggregation("rows", {
                    path: "/I_ProductStorageLocation",

                    filters: aAllFilters,
                    events: {
                      dataReceived: function () {
                        oDialogSuggestions.update();
                      },
                    },
                  });
                  oColumnStorageLocation = new UIColumn({
                    label: new Label({ text: this.changei18n("print.maincontroller_storage") }),
                    template: new Text({
                      wrapping: false,
                      text: "{StorageLocation}",
                    }),
                  });
                  oColumnStorageLocation.data({
                    fieldName: "StorageLocation",
                  });
                  oTable.addColumn(oColumnStorageLocation);

                  oColumnPlant = new UIColumn({
                    label: new Label({ text: this.changei18n("Print.maincontroller_plant") }),
                    template: new Text({ wrapping: false, text: this.changei18n("Print.maincontroller_plant") }),
                  });
                  oColumnPlant.data({
                    fieldName: "Plant",
                  });
                  oTable.addColumn(oColumnPlant);
                }

                // For Mobile the default table is sap.m.Table
                if (oTable.bindItems) {
                  // Bind items to the ODataModel and add columns
                  oTable.bindAggregation("items", {
                    path: "/I_ProductStorageLocation",

                    filters: aAllFilters,
                    template: new ColumnListItem({
                      cells: [
                        new Label({ text: this.changei18n("print.maincontroller_storage") }),
                        new Label({ text: this.changei18n("Print.maincontroller_plant") }),
                      ],
                    }),
                    events: {
                      dataReceived: function () {
                        oDialogSuggestions.update();
                      },
                    },
                  });
                  oTable.addColumn(
                    new MColumn({
                      header: new Label({ text: this.changei18n("print.maincontroller_storage") }),
                    })
                  );
                  oTable.addColumn(
                    new MColumn({ header: new Label({ text: this.changei18n("Print.maincontroller_plant") }) })
                  );
                }
                oDialogSuggestions.update();
              }.bind(this)
            );

            oDialogSuggestions.setTokens(
              this._oMultiInputWithSuggestionsSloc.getTokens()
            );
            oDialogSuggestions.open();
          }.bind(this)
        );
      },

      onValueHelpWithSuggestionsSlocOkPress: function (oEvent) {
        var aSloc = [];
        var aTokens = oEvent.getParameter("tokens");
        this._oMultiInputWithSuggestionsSloc.setTokens(aTokens);
        aTokens.forEach(function (oToken) {
          var sSlocKey = oToken.getKey();

          aSloc.push(sSlocKey);
        }, this);
        // --filter
        var aFilter = [];
        aTokens.forEach((token) => {
          var oFilter = this._formFilter(token, "StorageLocation");
          if (oFilter) aFilter.push(oFilter);
        });
        if (aSloc.length > 0) {
          var oSlocInput = this.getView().byId("multiInputWithSuggestionsSloc");
          var oModel = this.getView().getModel();

          // Set the collected materials to the model
          oModel.setProperty("/selectedSlocCondition", aFilter);
          oModel.setProperty("/selectedSloc", aSloc);

          // Set the tokens to the material input field
          oSlocInput.removeAllTokens();
          aSloc.forEach(function (sSloc) {
            oSlocInput.addToken(new sap.m.Token({ key: sSloc, text: sSloc }));
          });
        }

        this._oVHDWithSuggestions.close();
        this._onSlocChange();
      },

      onValueHelpWithSuggestionsSlocCancelPress: function () {
        this._oVHDWithSuggestions.close();
        this._onSlocChange();
      },
      onFilterBarWithSuggestionsSearchSloc: function (oEvent) {
        var sSearchQuery = this._oBasicSearchFieldWithSuggestions.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet"),
          aFilters =
            aSelectionSet &&
            aSelectionSet.reduce(function (aResult, oControl) {
              if (oControl.getValue()) {
                aResult.push(
                  new Filter({
                    path: oControl.getName(),
                    operator: FilterOperator.Contains,
                    value1: oControl.getValue(),
                  })
                );
              }

              return aResult;
            }, []);

        aFilters.push(
          new Filter({
            filters: [
              new Filter({
                path: "StorageLocation",
                operator: FilterOperator.Contains,
                value1: sSearchQuery,
              }),
              new Filter({
                path: "Plant",
                operator: FilterOperator.Contains,
                value1: sSearchQuery,
              }),
            ],
            and: false,
          })
        );

        this._filterTableWithSuggestionsSloc(
          new Filter({
            filters: aFilters,
            and: true,
          })
        );
      },
      _filterTableWithSuggestionsSloc: function (oFilter) {
        var oVHD = this._oVHDWithSuggestions;
        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }
          oVHD.update();
        });
      },
      onValueHelpWithSuggestionsSlocAfterClose: function () {
        this._oVHDWithSuggestions.destroy();

        this._onSlocChange();
      },

      //:--Printer help
      onValueHelpRequestPnt: function () {
        var that = this;
        var sPlant = this.byId("inputPlant").getValue().toUpperCase();
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog = new ValueHelpDialog({
            title: "Select Printer",
            supportMultiselect: false,
            ok: this._onValueHelpOkPnt.bind(this),
            cancel: this._onValueHelpCancelPnt.bind(this),
            afterClose: this._onValueHelpAfterClosePnt.bind(this),
          });
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label: this.changei18n("print.maincontroller_Printer"), template: "Printer" },
              { label: this.changei18n("print.maincontroller_Printdesc"), template: "PrinterDescription" },
              { label: this.changei18n("print.maincontroller_default"), template: "DefaultPrinter" },
              { label: this.changei18n("Print.maincontroller_plant"), template: "Plant" },
              { label: this.changei18n("print.maincontroller_loca"), template: "Location" },
              { label: this.changei18n("print.maincontroller_sap_des"), template: "SAP_Description" },
            ],
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            oTable.setModel(that.oProductsModel);

            oTable.bindAggregation("rows", {
              path: "/ZZ1_ZPM_CBO_PRINTER_DETAIL",
              filters: [new Filter("Plant", FilterOperator.EQ, sPlant)], //ZQM_E0239_POP_UP_QA32_WERKS

              events: {
                dataReceived: function () {
                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOkPnt: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").Printer;

          this.getView().byId("inputPrinter").setValue(sSelectedValue);
          this.getView()
            .getModel()
            .setProperty("/selectedPrinter", sSelectedValue);
        }
        this._oValueHelpDialog.close();
      },

      _onValueHelpCancelPnt: function () {
        this._oValueHelpDialog.close();
      },

      _onValueHelpAfterClosePnt: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End plant help

      _updateFieldWithDefaultPrinter: function (sPlant) {
        var that = this;
        var oModel = this.getOwnerComponent().getModel("ZPM_SB_PRINT_LABEL");

        var aFilters = [
          new Filter("Plant", FilterOperator.EQ, sPlant),
          new Filter("DefaultPrinter", FilterOperator.EQ, true),
        ];

        // Make the OData read call
        oModel.read("/ZZ1_ZPM_CBO_PRINTER_DETAIL", {
          filters: aFilters,
          success: function (oData) {
            // Handle success response
            if (oData.results && oData.results.length > 0) {
              var oFirstResult = oData.results[0];

              that.oPrinterInput.setValue(oFirstResult.Printer);
            } else {
              that.oPrinterInput.setValue(""); // Clear the input field if no results
            }
          },
          error: function (oError) {
            var oResourceModel = this.getView().getModel("i18n"),
						oBundle = oResourceModel.getResourceBundle();
            // Handle error response
            console.error(oBundle.getText("print.maincontroller_srvice"));
            that.oPrinterInput.setValue(""); // Clear the input field on error
          },
        });
      },

      onExecute: async function () {
        var oModel = this.oModel;
        var sPlant = this.byId("inputPlant").getValue().toUpperCase();
        var sStoragebin = this.byId("inputBin").getValue();
        var sPrinter = this.byId("inputPrinter").getValue();
        var sInput = this.byId("inputNoOfCount").getValue();
        var validPrinter = false;
        var sMaterial = this.byId("multiInputWithSuggestionsMat").getValue();
        var sSloc = this.byId("multiInputWithSuggestionsSloc")
          .getValue()
          .toUpperCase();
        var sMaterialfilter = this.getView()
          .getModel()
          .getProperty("/selectedMatCondition");
        var sSlocfilter = this.getView()
          .getModel()
          .getProperty("/selectedSlocCondition");

        var oPlantFilter = new Filter("Plant", FilterOperator.EQ, sPlant);
        var oPrinterFilter = new Filter("Printer", FilterOperator.EQ, sPrinter);
        var aValidPrinter = [oPlantFilter, oPrinterFilter];
        const isValid = await this._validatePlantAndInput(aValidPrinter);

        if (!isValid) {
          var oResourceModel = this.getView().getModel("i18n"),
						oBundle = oResourceModel.getResourceBundle();
          sap.m.MessageBox.error(oBundle.getText("print.maincotroller_entries"));

          // sap.m.MessageBox.error("Invalid Printer. Please check your entries.");
          return false;
        }
        var oMaterialFilter;
        var oStorageFilter;
        //:-
        if (sMaterial) {
          oMaterialFilter = new Filter("Product", FilterOperator.EQ, sMaterial);
        } else {
          oMaterialFilter = new Filter({
            filters: sMaterialfilter,
            and: false,
          });
        }

        if (sSloc) {
          oStorageFilter = new Filter(
            "StorageLocation",
            FilterOperator.EQ,
            sSloc
          );
        } else {
          oStorageFilter = new Filter({
            filters: sSlocfilter,
            and: false,
          });
        }
        //:-
        // Combine all filters with AND operator
        var aCombinedFilters = [oPlantFilter, oMaterialFilter, oStorageFilter];

        // Add Storage Bin filter if provided
        if (sStoragebin) {
          var oSbinFilter = new Filter(
            "WarehouseStorageBin",
            FilterOperator.EQ,
            sStoragebin
          );
          aCombinedFilters.push(oSbinFilter);
        }

        // Apply combined filter to the OData request
        var aResults = await this._applyFilters(
          new Filter(aCombinedFilters, true)
        );
        var updatedData = aResults.map(function (item) {
          return {
            ...item, // spread operator to copy existing properties
            barten_print: sPrinter,
            no_print: sInput,
          };
        });
        if (updatedData.length > 0) {
          try {
            BusyIndicator.show();
            var responseValue = this.postbatchcall(updatedData);
          } catch (error) {
            BusyIndicator.hide();
            sap.m.MessageToast.show(`Error: ${error}`);
          }
        } else {
          var oResourceModel = this.getView().getModel("i18n"),
						oBundle = oResourceModel.getResourceBundle();
          sap.m.MessageBox.error(oBundle.getText("print.maincontroller_message"));
          // sap.m.MessageToast.show(
          //   "No Product is available with provided combination "
          // );
        }
      },
      _applyFilters: function (aFilters) {
        var oModel = this.oModel; // Ensure this is properly initialized in your controller
        var sPath = "/I_ProductStorageLocation";

        return new Promise(
          function (resolve, reject) {
            oModel.read(sPath, {
              filters: [aFilters],
              success: function (oData) {
                // Process the data
                var result = oData.results.map(function (item) {
                  return {
                    Plant: item.Plant,
                    Material: item.Product,
                    stloc: item.StorageLocation,
                    st_bin: item.WarehouseStorageBin,
                  };
                });

                // Optional: Bind the result to a table or list in your view
                var oResultModel = new sap.ui.model.json.JSONModel(result);
                this.getView().setModel(oResultModel, "resultModel");

                // Resolve the Promise with the processed result
                resolve(result);
              }.bind(this),
              error: function (oError) {
                console.error("Error fetching data:", oError);
                // Reject the Promise with the error
                reject(oError);
              },
            });
          }.bind(this)
        ); // Ensure 'this' context is bound correctly
      },

      _onMultiInputValidate: function (oArgs) {
        var sWhitespace = " ",
          sUnicodeWhitespaceCharacter = "\u00A0"; // Non-breaking whitespace

        if (oArgs.suggestionObject) {
          var oObject = oArgs.suggestionObject.getBindingContext().getObject(),
            oToken = new Token(),
            sOriginalText = oObject.ProductCode.replaceAll(
              sWhitespace + sWhitespace,
              sWhitespace + sUnicodeWhitespaceCharacter
            );

          oToken.setKey(oObject.ProductCode);

          return oToken;
        }
        return null;
      },

      _onMultiInputValidateSloc: function (oArgs) {
        var sWhitespace = " ",
          sUnicodeWhitespaceCharacter = "\u00A0"; // Non-breaking whitespace

        if (oArgs.suggestionObject) {
          debugger;
          var oObject = oArgs.suggestionObject.getBindingContext().getObject(),
            oToken = new Token(),
            sOriginalText = oObject.StorageLocation.replaceAll(
              sWhitespace + sWhitespace,
              sWhitespace + sUnicodeWhitespaceCharacter
            );

          oToken.setKey(oObject.StorageLocation);
          // oToken.setText(oObject.ProductName + " (" + sOriginalText + ")");   // to give description in select
          return oToken;
        }
        return null;
      },
      _formFilter: function (oToken, sFieldPath) {
        var oFilterObj = {};
        var sKeyType = oToken
          .getAggregation("customData")[0]
          .getProperty("key");

        switch (sKeyType) {
          case "row": {
            oFilterObj = new Filter({
              path: sFieldPath,
              operator: FilterOperator.Contains,
              value1: oToken.getKey(),
            });
            break;
          }
          case "range": {
            var oValue = oToken
              .getAggregation("customData")[0]
              .getProperty("value");
            oFilterObj = new Filter({
              path: oValue.keyField,
              operator: FilterOperator[oValue.operation],
              value1: oValue.value1,
              value2: oValue.value2,
            });
          }
        }
        return oFilterObj;
      },

      // batch call

      postbatchcall: function (payloadsArray) {
        return new Promise((resolve, reject) => {
          var oModel = this.oModel;
          var that = this;
          // var oModel = this.getView().getModel("mainModel");
          oModel.setUseBatch(true);
          oModel.setDeferredGroups(["postCallsGroup"]);

          if (payloadsArray && payloadsArray.length > 0) {
            for (let index = 0; index < payloadsArray.length; index++) {
              oModel.create("/zpm_cds_i_Print_label", payloadsArray[index], {
                groupId: "postCallsGroup",
                method: "POST",
                success: function (data) {
                  // that.resetAll();
                },
                error: function (error) {
                  console.log("Error: ", error);
                },
              });
            }

            oModel.submitChanges({
              groupId: "postCallsGroup",
              success: (data) => {
                var oResourceModel = this.getView().getModel("i18n"),
						oBundle = oResourceModel.getResourceBundle();
                console.log(oBundle.getText("print.maincontroller_batch"));
                if(data.__batchResponses[0] && data.__batchResponses[0].__changeResponses){
                var sapMessageHeader =
                  data.__batchResponses[0].__changeResponses[0].headers[
                    "sap-message"
                  ];
                var sapMessage = JSON.parse(sapMessageHeader);
                var severity = sapMessage.severity;
                var message = sapMessage.message;
                BusyIndicator.hide();
                sap.m.MessageToast.show(
                  `Status: ${severity} \n  Message:" ${message} `
                );
                this.onSuccesspost();
                resolve();
              }
              else{
                BusyIndicator.hide();
                sap.m.MessageToast.show(data.__batchResponses[0].message);
                reject( data.__batchResponses[0].message);
              }
              },
              error: (error) => {
                console.log("Error: ", JSON.stringify(error));
                BusyIndicator.hide();
                reject(error);
              },
            });
          } else {
            resolve(); // Resolve the promise if payloadsArray is empty
          }
        });
      },

      mandateCheck: async function (oEvent) {
        var matValue =
          this.oMaterialInput.getValue() ||
          this.oMaterialInput.getTokens().length > 0;

        var slocvalue =
          this.oStorageLocation.getValue() ||
          this.oStorageLocation.getTokens().length > 0;
        var plantValue = this.oPlantInput.getValue();
        var printerValue = this.oPrinterInput.getValue();
        var pcountValue = this.oNoOfCountInput.getValue();
        if (
          matValue &&
          slocvalue &&
          plantValue &&
          printerValue &&
          pcountValue
        ) {
          this._setButtonEnabled(true);
        } else {
          this._setButtonEnabled(false);
        }
      },
      _checkPlantAvailability: function (oModel, aFilters) {
        return new Promise(function (resolve, reject) {
          oModel.read("/I_Plant", {
            filters: aFilters,
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },
      _checkMaterialAvailability: function (oModel, aFilters) {
        return new Promise(function (resolve, reject) {
          oModel.read("/zpm_cds_matrial_F4", {
            filters: aFilters,
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },
      onMaterialChange: function (oEvent) {
        this.mandateCheck();
      },
      onValueChange: async function () {
        //:--
        var materialFlag = false;
        var sMaterialValue = this.byId(
          "multiInputWithSuggestionsMat"
        ).getValue();
        var sMaterialToken = this.byId(
          "multiInputWithSuggestionsMat"
        ).getTokens(); //git
        var oModel = this.getOwnerComponent().getModel("ZPM_SB_PRINT_LABEL"); // Assuming you have defined your model in the manifest

        var aFilters = [
          new Filter("Product", FilterOperator.EQ, sMaterialValue),
        ];

        try {
          var oData = await this._checkMaterialAvailability(oModel, aFilters);
          if (
            (oData.results && oData.results.length > 0) ||
            sMaterialToken.length > 0
          ) {
            materialFlag = true;
          } else {
            var oResourceModel = this.getView().getModel("i18n"),
						oBundle = oResourceModel.getResourceBundle();
          sap.m.MessageBox.error(oBundle.getText("print.maincontroller_Producterror"));
            // sap.m.MessageToast.show("Product is not available.");
            materialFlag = false;
          }
        } catch (oError) {
          var oResourceModel = this.getView().getModel("i18n"),
						oBundle = oResourceModel.getResourceBundle();
          // sap.m.MessageBox.error(oBundle.getText("print.maincontroller_Producterror"));
          MessageToast.show
            (oBundle.getText("print.maincontroller_Producterror"));
        }

        if (!materialFlag) {
          this.byId("multiInputWithSuggestionsSloc").setTokens([]);
          this.byId("multiInputWithSuggestionsSloc").setValue("");
          this._setButtonEnabled(false);
          this._setSlocInputEnabled(false);
        } else {
          this._setSlocInputEnabled(true);
        }

        this.mandateCheck();
      },
      onMterialLiveChange: function (oEvent) {
        var oMultiInput = oEvent.getSource();
        var sValue = oMultiInput.getValue();

        sValue = sValue.replace(/[^a-zA-Z0-9]/g, "");

        if (sValue.length > 18) {
          sValue = sValue.substring(0, 18);
        }
        // Update the value
        if (this.oMaterialInput.getTokens().length > 0) {
          oMultiInput.setValue("");
        } else {
          oMultiInput.setValue(sValue);
          this.onValueChange();
        }
      },
      onSuccesspost: function () {
        this._setButtonEnabled(false);
        this.byId("multiInputWithSuggestionsMat").setTokens([]);
        this.byId("multiInputWithSuggestionsMat").setValue("");
        this.byId("inputBin").setValue("");
        this.byId("multiInputWithSuggestionsSloc").setTokens([]);
        this.byId("multiInputWithSuggestionsSloc").setValue("");
        this.byId("inputPrinter").setValue("");
        this.byId("inputPlant").setValue("");
      },
      _validatePlantAndInput: function (oFilter) {
        return new Promise(
          function (resolve, reject) {
            var oModel = this.oModel;

            oModel.read("/ZZ1_ZPM_CBO_PRINTER_DETAIL", {
              filters: oFilter,
              success: function (oData) {
                if (oData.results && oData.results.length > 0) {
                  resolve(true); // Validation passed
                } else {
                  resolve(false); // Validation failed
                }
              },
              error: function (oError) {
                reject(oError); // Handle error during OData read
              },
            });
          }.bind(this)
        );
      },
    });
  }
);
