sap.ui.define([
	"comwldts/zmatpmlabel/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
